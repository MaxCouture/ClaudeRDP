import React, { useState, useEffect } from "react";
import { TeamsChannel } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Edit3, Save, X, MessageSquare, AlertTriangle, CheckCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Toaster } from "@/components/ui/toaster";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";

function ChannelModal({ channel, isOpen, onClose, onSave }) {
  const [formData, setFormData] = useState({
    name: "",
    webhook_url: "",
    description: "",
    is_active: true
  });

  useEffect(() => {
    if (channel) {
      setFormData({
        name: channel.name || "",
        webhook_url: channel.webhook_url || "",
        description: channel.description || "",
        is_active: channel.is_active !== false
      });
    } else {
      setFormData({
        name: "",
        webhook_url: "",
        description: "",
        is_active: true
      });
    }
  }, [channel, isOpen]);

  const handleSave = () => {
    onSave(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {channel ? 'Modifier le canal' : 'Nouveau canal Teams'}
          </DialogTitle>
          <DialogDescription>
            Configurez un webhook Microsoft Teams pour recevoir des alertes
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div>
            <Label>Nom du canal *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              placeholder="Ex: Équipe Marketing, Direction, Urgences"
            />
          </div>
          
          <div>
            <Label>URL du Webhook Teams *</Label>
            <Input
              value={formData.webhook_url}
              onChange={(e) => setFormData({...formData, webhook_url: e.target.value})}
              placeholder="https://outlook.office.com/webhook/..."
              type="url"
            />
            <p className="text-xs text-gray-500 mt-1">
              Pour obtenir l'URL : Teams → Canal → ⋯ → Connecteurs → Webhook entrant
            </p>
          </div>

          <div>
            <Label>Description (optionnel)</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              placeholder="Description du canal et de son utilisation"
              rows={2}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="is_active"
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
            />
            <Label htmlFor="is_active">Canal actif</Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button 
            onClick={handleSave} 
            disabled={!formData.name.trim() || !formData.webhook_url.trim()}
          >
            <Save className="w-4 h-4 mr-2" />
            Sauvegarder
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function TeamsChannelsPage() {
  const [channels, setChannels] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingChannel, setEditingChannel] = useState(null);
  const { toast } = useToast();

  const loadChannels = async () => {
    setIsLoading(true);
    try {
      const data = await TeamsChannel.list();
      setChannels(data);
    } catch (error) {
      console.error("Erreur chargement canaux:", error);
      toast({ title: "Erreur", description: "Impossible de charger les canaux.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadChannels();
  }, []);

  const handleSave = async (formData) => {
    try {
      if (editingChannel) {
        await TeamsChannel.update(editingChannel.id, formData);
        toast({ title: "Canal modifié", description: "Le canal a été mis à jour." });
      } else {
        await TeamsChannel.create(formData);
        toast({ title: "Canal créé", description: "Le nouveau canal a été créé." });
      }
      setShowModal(false);
      setEditingChannel(null);
      loadChannels();
    } catch (error) {
      console.error("Erreur sauvegarde canal:", error);
      toast({ title: "Erreur", description: "Impossible de sauvegarder le canal.", variant: "destructive" });
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Êtes-vous sûr de vouloir supprimer ce canal ?")) {
      try {
        await TeamsChannel.delete(id);
        toast({ title: "Canal supprimé", description: "Le canal a été supprimé." });
        loadChannels();
      } catch (error) {
        console.error("Erreur suppression canal:", error);
        toast({ title: "Erreur", description: "Impossible de supprimer le canal.", variant: "destructive" });
      }
    }
  };

  const handleToggleActive = async (channel) => {
    try {
      await TeamsChannel.update(channel.id, { is_active: !channel.is_active });
      toast({ 
        title: channel.is_active ? "Canal désactivé" : "Canal activé",
        description: `Le canal "${channel.name}" a été ${channel.is_active ? 'désactivé' : 'activé'}.`
      });
      loadChannels();
    } catch (error) {
      console.error("Erreur changement statut:", error);
      toast({ title: "Erreur", description: "Impossible de changer le statut.", variant: "destructive" });
    }
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-pink-600 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Canaux Microsoft Teams</h1>
            <p className="text-gray-600">Gérez les destinations de vos alertes</p>
          </div>
        </div>
        <Button onClick={() => { setEditingChannel(null); setShowModal(true); }}>
          <Plus className="w-4 h-4 mr-2" />
          Nouveau canal
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            Canaux configurés ({channels.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-center text-gray-500 py-8">Chargement...</p>
          ) : channels.length === 0 ? (
            <div className="text-center py-12">
              <AlertTriangle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Aucun canal configuré</h3>
              <p className="text-gray-500 mb-4">Créez votre premier canal Teams pour recevoir des alertes.</p>
              <Button onClick={() => { setEditingChannel(null); setShowModal(true); }}>
                <Plus className="w-4 h-4 mr-2" />
                Créer un canal
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {channels.map(channel => (
                <Card key={channel.id} className="border">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-bold text-lg">{channel.name}</h3>
                          <Badge variant={channel.is_active ? "default" : "secondary"} className="text-xs">
                            {channel.is_active ? (
                              <>
                                <CheckCircle className="w-3 h-3 mr-1" />
                                Actif
                              </>
                            ) : (
                              "Inactif"
                            )}
                          </Badge>
                        </div>
                        {channel.description && (
                          <p className="text-sm text-gray-600 mb-2">{channel.description}</p>
                        )}
                        <p className="text-xs text-gray-400 font-mono truncate">
                          {channel.webhook_url}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 ml-4">
                        <Switch
                          checked={channel.is_active}
                          onCheckedChange={() => handleToggleActive(channel)}
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => { setEditingChannel(channel); setShowModal(true); }}
                        >
                          <Edit3 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(channel.id)}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-900 text-sm">💡 Comment configurer un webhook Teams</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-blue-800 space-y-2">
          <ol className="list-decimal list-inside space-y-1">
            <li>Ouvrez Microsoft Teams et sélectionnez votre canal</li>
            <li>Cliquez sur les trois points (⋯) à côté du nom du canal</li>
            <li>Sélectionnez "Connecteurs" → "Webhook entrant"</li>
            <li>Donnez un nom au webhook et cliquez sur "Créer"</li>
            <li>Copiez l'URL générée et collez-la ici</li>
          </ol>
        </CardContent>
      </Card>

      <ChannelModal
        channel={editingChannel}
        isOpen={showModal}
        onClose={() => { setShowModal(false); setEditingChannel(null); }}
        onSave={handleSave}
      />

      <Toaster />
    </div>
  );
}