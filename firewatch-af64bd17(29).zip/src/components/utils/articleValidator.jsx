import { parseRobustDate, sanitizeDate } from './dateValidator';

export const validateArticle = (article) => {
  const errors = [];
  
  // Validation ID
  if (!article.id) {
    errors.push('Missing article ID');
    return { isValid: false, errors, sanitized: null };
  }
  
  // Validation titre
  if (!article.title || typeof article.title !== 'string') {
    errors.push('Invalid or missing title');
  }
  
  // Validation date avec le nouveau système robuste
  let sanitizedDate = article.publication_date;
  if (article.publication_date) {
    try {
      const { date, isValid, strategy } = parseRobustDate(article.publication_date);
      
      if (!isValid || strategy === 'fallback') {
        console.warn(`Article ${article.id}: Date invalide, utilisation de maintenant`);
        sanitizedDate = new Date().toISOString();
      } else if (strategy === 'future_corrected') {
        console.warn(`Article ${article.id}: Date future corrigée`);
        sanitizedDate = date.toISOString();
      } else {
        sanitizedDate = date.toISOString();
      }
    } catch (e) {
      console.error(`Article ${article.id}: Erreur critique parsing date`, e);
      errors.push('Critical error parsing publication_date');
      sanitizedDate = new Date().toISOString();
    }
  } else {
    sanitizedDate = new Date().toISOString();
  }
  
  // Validation source
  if (!article.source_id) {
    errors.push('Missing source_id');
  }
  
  // Article sanitisé
  const sanitized = {
    ...article,
    title: article.title || 'Sans titre',
    publication_date: sanitizedDate,
    _searchTitle: (article.title || '').toLowerCase(),
    _timestamp: new Date(sanitizedDate).getTime(),
    categories: Array.isArray(article.categories) ? article.categories : [],
    content: article.content || '',
    summary: article.summary || ''
  };
  
  return {
    isValid: errors.length === 0,
    errors,
    sanitized
  };
};

export const validateAndSanitizeArticles = (articles) => {
  const valid = [];
  const invalid = [];
  
  articles.forEach(article => {
    const result = validateArticle(article);
    
    if (result.sanitized) {
      valid.push(result.sanitized);
      
      if (result.errors.length > 0) {
        console.warn(`Article ${article.id} sanitisé:`, result.errors);
      }
    } else {
      invalid.push({ article, errors: result.errors });
      console.error(`Article ${article.id} invalide:`, result.errors);
    }
  });
  
  return { valid, invalid };
};