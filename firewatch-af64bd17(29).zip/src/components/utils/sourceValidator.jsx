/**
 * Validateur de sources - VERSION CLIENT
 * Appelle la fonction backend pour contourner CORS
 */

import { base44 } from '@/api/base44Client';

/**
 * Valide une nouvelle source via le backend (contourne CORS)
 */
export const validateNewSource = async (formData, existingSources = []) => {
  try {
    const { data } = await base44.functions.invoke('validateSource', {
      url: formData.url,
      type: formData.type,
      existingSources: existingSources.map(s => ({ 
        name: s.name, 
        url: s.url 
      }))
    });

    return data;
  } catch (error) {
    console.error('Erreur validation source:', error);
    return {
      isValid: false,
      errors: [`Erreur de validation: ${error.message}`],
      warnings: [],
      metadata: {}
    };
  }
};

/**
 * Formate les résultats de validation pour l'affichage
 */
export const formatValidationResults = (validation) => {
  const lines = [];
  
  if (validation.metadata.responseTime) {
    lines.push(`⏱️ ${(validation.metadata.responseTime / 1000).toFixed(2)}s`);
  }
  
  if (validation.metadata.articlesFound !== undefined) {
    lines.push(`📰 ${validation.metadata.articlesFound} articles`);
  }
  
  if (validation.metadata.feedTitle) {
    lines.push(`📝 ${validation.metadata.feedTitle}`);
  }
  
  validation.warnings?.forEach(w => lines.push(w));
  
  return lines;
};