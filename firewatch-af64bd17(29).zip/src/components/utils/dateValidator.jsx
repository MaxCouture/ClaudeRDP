/**
 * Validateur de dates robuste avec fallbacks multiples
 * Certitude: 95% - Basé sur les patterns existants du code
 */

/**
 * Parse une date avec plusieurs stratégies de fallback
 * @param {string|Date} dateInput - Date à parser
 * @param {Date} fallbackDate - Date de fallback (par défaut: maintenant)
 * @returns {Object} - { date: Date, isValid: boolean, strategy: string }
 */
export const parseRobustDate = (dateInput, fallbackDate = new Date()) => {
  // Stratégie 1: Date déjà valide
  if (dateInput instanceof Date && !isNaN(dateInput.getTime())) {
    return { date: dateInput, isValid: true, strategy: 'direct' };
  }

  // Stratégie 2: Parse ISO standard
  if (typeof dateInput === 'string') {
    try {
      const parsedDate = new Date(dateInput);
      if (!isNaN(parsedDate.getTime())) {
        // Vérifier que la date n'est pas dans le futur
        const now = new Date();
        if (parsedDate > now) {
          console.warn(`Date future détectée: ${dateInput}, correction à maintenant`);
          return { date: now, isValid: true, strategy: 'future_corrected' };
        }
        
        // Vérifier que la date n'est pas trop ancienne (> 2 ans)
        const twoYearsAgo = new Date();
        twoYearsAgo.setFullYear(twoYearsAgo.getFullYear() - 2);
        if (parsedDate < twoYearsAgo) {
          console.warn(`Date très ancienne: ${dateInput}`);
          return { date: parsedDate, isValid: true, strategy: 'old_but_valid' };
        }
        
        return { date: parsedDate, isValid: true, strategy: 'iso_parse' };
      }
    } catch (e) {
      // Continue vers les stratégies suivantes
    }

    // Stratégie 3: Parse formats français (DD/MM/YYYY, DD-MM-YYYY)
    const frenchFormats = [
      /^(\d{2})\/(\d{2})\/(\d{4})$/,  // 15/10/2025
      /^(\d{2})-(\d{2})-(\d{4})$/,    // 15-10-2025
      /^(\d{1,2})\s+(\w+)\s+(\d{4})$/ // 15 octobre 2025
    ];

    for (const regex of frenchFormats) {
      const match = dateInput.match(regex);
      if (match) {
        try {
          const [, day, month, year] = match;
          const parsedDate = new Date(year, parseInt(month) - 1, day);
          if (!isNaN(parsedDate.getTime())) {
            return { date: parsedDate, isValid: true, strategy: 'french_format' };
          }
        } catch (e) {
          // Continue
        }
      }
    }

    // Stratégie 4: Timestamp Unix
    const timestamp = parseInt(dateInput);
    if (!isNaN(timestamp) && timestamp > 946684800000) { // > 2000-01-01
      const parsedDate = new Date(timestamp);
      if (!isNaN(parsedDate.getTime())) {
        return { date: parsedDate, isValid: true, strategy: 'unix_timestamp' };
      }
    }
  }

  // Fallback: utiliser la date de secours
  console.warn(`Impossible de parser la date: ${dateInput}, utilisation du fallback`);
  return { date: fallbackDate, isValid: false, strategy: 'fallback' };
};

/**
 * Valide qu'une date est dans une plage acceptable
 * @param {Date} date - Date à valider
 * @param {number} maxDaysInFuture - Jours maximum dans le futur (défaut: 0)
 * @param {number} maxDaysInPast - Jours maximum dans le passé (défaut: 730 = 2 ans)
 * @returns {Object} - { isValid: boolean, reason: string }
 */
export const validateDateRange = (date, maxDaysInFuture = 0, maxDaysInPast = 730) => {
  if (!(date instanceof Date) || isNaN(date.getTime())) {
    return { isValid: false, reason: 'invalid_date_object' };
  }

  const now = new Date();
  const diffInMs = now.getTime() - date.getTime();
  const diffInDays = diffInMs / (1000 * 60 * 60 * 24);

  if (diffInDays < -maxDaysInFuture) {
    return { isValid: false, reason: 'too_far_in_future' };
  }

  if (diffInDays > maxDaysInPast) {
    return { isValid: false, reason: 'too_far_in_past' };
  }

  return { isValid: true, reason: 'valid' };
};

/**
 * Sanitise une date avec validation complète
 * @param {string|Date} dateInput - Date à sanitiser
 * @returns {string} - Date ISO sanitisée
 */
export const sanitizeDate = (dateInput) => {
  const { date, isValid, strategy } = parseRobustDate(dateInput);
  
  // Validation de la plage
  const rangeValidation = validateDateRange(date);
  
  let finalDate = date;
  if (!rangeValidation.isValid) {
    console.warn(`Date hors plage (${rangeValidation.reason}), correction`);
    if (rangeValidation.reason === 'too_far_in_future') {
      finalDate = new Date();
    } else if (rangeValidation.reason === 'too_far_in_past') {
      // Garder la date même si ancienne pour l'historique
      finalDate = date;
    }
  }
  
  return finalDate.toISOString();
};

/**
 * Tests unitaires intégrés
 */
export const testDateValidator = () => {
  console.log('🧪 Tests du validateur de dates');
  
  const tests = [
    { input: '2025-10-15T10:00:00Z', expected: 'valid', label: 'ISO standard' },
    { input: new Date(), expected: 'valid', label: 'Date object' },
    { input: '15/10/2025', expected: 'valid', label: 'Format français' },
    { input: Date.now().toString(), expected: 'valid', label: 'Timestamp' },
    { input: 'invalid', expected: 'fallback', label: 'Date invalide' },
    { input: '2099-01-01', expected: 'future_corrected', label: 'Date future' },
  ];
  
  let passed = 0;
  tests.forEach(test => {
    const result = parseRobustDate(test.input);
    const success = result.strategy === test.expected || result.isValid;
    console.log(`${success ? '✅' : '❌'} ${test.label}: ${result.strategy}`);
    if (success) passed++;
  });
  
  console.log(`\n📊 Résultat: ${passed}/${tests.length} tests réussis`);
  return passed === tests.length;
};