/**
 * Orchestrateur de scan robuste
 */

import { sourceHealthMonitor, ERROR_TYPES } from './sourceHealthMonitor';

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const withTimeoutAndRetry = async (fn, timeoutMs, maxRetries, sourceName) => {
  let lastError = null;
  
  for (let attempt = 1; attempt <= maxRetries + 1; attempt++) {
    try {
      const result = await Promise.race([
        fn(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Timeout')), timeoutMs)
        )
      ]);
      
      return { success: true, data: result };
      
    } catch (error) {
      lastError = error;
      console.warn(`⚠️ ${sourceName} - Tentative ${attempt} échouée`);
      
      if (attempt <= maxRetries) {
        await delay(2000 * attempt);
      }
    }
  }
  
  return { 
    success: false, 
    error: lastError.message,
    errorType: lastError.message.includes('Timeout') ? ERROR_TYPES.TIMEOUT : ERROR_TYPES.NETWORK
  };
};

const processSingleSource = async (sourceConfig, scanOptions = {}) => {
  const { source, scanFunction, timeout = 30000, sourceName } = sourceConfig;
  const startTime = Date.now();
  
  console.log(`📡 ${sourceName}`);
  
  try {
    if (source?.id && !sourceHealthMonitor.shouldIncludeInScan(source.id)) {
      console.log(`⏭️ ${sourceName} - Sauté (DOWN)`);
      return {
        sourceName,
        sourceId: source?.id,
        skipped: true,
        reason: 'down_recently',
        articlesAdded: 0
      };
    }
    
    const result = await withTimeoutAndRetry(
      () => scanFunction(scanOptions),
      timeout,
      1,
      sourceName
    );
    
    const duration = Date.now() - startTime;
    
    if (result.success) {
      const articlesAdded = result.data?.data?.created || 
                           result.data?.created || 0;
      
      console.log(`✅ ${sourceName} - ${articlesAdded} articles`);
      
      if (source?.id) {
        sourceHealthMonitor.recordSuccess(source.id, articlesAdded);
      }
      
      return {
        sourceName,
        sourceId: source?.id,
        success: true,
        articlesAdded,
        duration
      };
      
    } else {
      console.error(`❌ ${sourceName} - ${result.error}`);
      
      if (source?.id) {
        sourceHealthMonitor.recordFailure(
          source.id,
          result.errorType,
          result.error
        );
      }
      
      return {
        sourceName,
        sourceId: source?.id,
        success: false,
        error: result.error,
        duration
      };
    }
    
  } catch (error) {
    console.error(`❌ ${sourceName} - Exception`);
    
    if (source?.id) {
      sourceHealthMonitor.recordFailure(
        source.id,
        ERROR_TYPES.SERVER_ERROR,
        error.message
      );
    }
    
    return {
      sourceName,
      sourceId: source?.id,
      success: false,
      error: error.message
    };
  }
};

export const orchestrateScan = async (sourcesConfig, scanOptions = {}, onProgress = null) => {
  console.log(`🎬 Scan: ${sourcesConfig.length} sources`);
  
  const results = [];
  
  for (let i = 0; i < sourcesConfig.length; i++) {
    const sourceConfig = sourcesConfig[i];
    
    if (onProgress) {
      onProgress({
        current: i + 1,
        total: sourcesConfig.length,
        sourceName: sourceConfig.sourceName
      });
    }
    
    const result = await processSingleSource(sourceConfig, scanOptions);
    results.push(result);
    
    if (i < sourcesConfig.length - 1) {
      await delay(500);
    }
  }
  
  const stats = {
    total: results.length,
    successful: results.filter(r => r.success).length,
    failed: results.filter(r => !r.success && !r.skipped).length,
    skipped: results.filter(r => r.skipped).length,
    totalArticles: results.reduce((sum, r) => sum + (r.articlesAdded || 0), 0),
    results: results
  };
  
  console.log(`🎉 ${stats.successful}/${stats.total} OK, ${stats.totalArticles} articles`);
  
  return stats;
};