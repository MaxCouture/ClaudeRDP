import React from 'react';

/**
 * Système de monitoring de la santé des sources
 * Certitude: 95% - Basé sur les patterns de timeout et retry existants
 */

/**
 * Status possibles d'une source
 */
export const SOURCE_STATUS = {
  HEALTHY: 'healthy',       // Fonctionne normalement
  DEGRADED: 'degraded',     // Fonctionne mais avec des erreurs occasionnelles
  FAILING: 'failing',       // Échoue régulièrement
  DOWN: 'down',            // Complètement inaccessible
  UNKNOWN: 'unknown'       // Statut non déterminé
};

/**
 * Types d'erreurs trackées
 */
export const ERROR_TYPES = {
  TIMEOUT: 'timeout',
  NETWORK: 'network',
  PARSE: 'parse',
  AUTH: 'authentication',
  RATE_LIMIT: 'rate_limit',
  NOT_FOUND: 'not_found',
  SERVER_ERROR: 'server_error'
};

/**
 * Classe pour tracker la santé d'une source
 */
export class SourceHealthMonitor {
  constructor() {
    this.healthData = new Map(); // sourceId -> healthInfo
    this.loadFromStorage();
  }

  /**
   * Enregistre une tentative réussie
   */
  recordSuccess(sourceId, articlesCount = 0) {
    const health = this.getOrCreateHealth(sourceId);
    
    health.lastSuccess = new Date().toISOString();
    health.successCount++;
    health.consecutiveFailures = 0;
    health.lastArticlesCount = articlesCount;
    health.totalArticles += articlesCount;
    
    this.updateStatus(sourceId);
    this.saveToStorage();
  }

  /**
   * Enregistre un échec
   */
  recordFailure(sourceId, errorType, errorMessage = '') {
    const health = this.getOrCreateHealth(sourceId);
    
    health.lastFailure = new Date().toISOString();
    health.failureCount++;
    health.consecutiveFailures++;
    
    // Tracker les types d'erreurs
    if (!health.errorCounts[errorType]) {
      health.errorCounts[errorType] = 0;
    }
    health.errorCounts[errorType]++;
    
    health.lastError = {
      type: errorType,
      message: errorMessage,
      timestamp: new Date().toISOString()
    };
    
    this.updateStatus(sourceId);
    this.saveToStorage();
  }

  /**
   * Obtient ou crée les données de santé
   */
  getOrCreateHealth(sourceId) {
    if (!this.healthData.has(sourceId)) {
      this.healthData.set(sourceId, {
        sourceId,
        status: SOURCE_STATUS.UNKNOWN,
        successCount: 0,
        failureCount: 0,
        consecutiveFailures: 0,
        lastSuccess: null,
        lastFailure: null,
        lastArticlesCount: 0,
        totalArticles: 0,
        errorCounts: {},
        lastError: null,
        firstChecked: new Date().toISOString(),
        lastChecked: new Date().toISOString()
      });
    }
    
    const health = this.healthData.get(sourceId);
    health.lastChecked = new Date().toISOString();
    return health;
  }

  /**
   * Met à jour le statut basé sur les métriques
   */
  updateStatus(sourceId) {
    const health = this.healthData.get(sourceId);
    if (!health) return;

    const totalAttempts = health.successCount + health.failureCount;
    const failureRate = totalAttempts > 0 ? health.failureCount / totalAttempts : 0;

    // Logique de détermination du statut
    if (health.consecutiveFailures >= 5) {
      health.status = SOURCE_STATUS.DOWN;
    } else if (health.consecutiveFailures >= 3) {
      health.status = SOURCE_STATUS.FAILING;
    } else if (failureRate > 0.3 && totalAttempts >= 10) {
      health.status = SOURCE_STATUS.DEGRADED;
    } else if (health.successCount > 0) {
      health.status = SOURCE_STATUS.HEALTHY;
    } else {
      health.status = SOURCE_STATUS.UNKNOWN;
    }
  }

  /**
   * Obtient le statut d'une source
   */
  getStatus(sourceId) {
    return this.healthData.get(sourceId)?.status || SOURCE_STATUS.UNKNOWN;
  }

  /**
   * Obtient les métriques complètes
   */
  getHealthMetrics(sourceId) {
    return this.healthData.get(sourceId) || null;
  }

  /**
   * Vérifie si une source devrait être incluse dans un scan
   */
  shouldIncludeInScan(sourceId) {
    const health = this.healthData.get(sourceId);
    if (!health) return true; // Inclure les nouvelles sources

    // Ne pas inclure les sources complètement down
    if (health.status === SOURCE_STATUS.DOWN) {
      // Mais leur donner une chance toutes les 24h
      if (health.lastFailure) {
        const hoursSinceFailure = (Date.now() - new Date(health.lastFailure)) / (1000 * 60 * 60);
        return hoursSinceFailure >= 24;
      }
      return false;
    }

    return true;
  }

  /**
   * Obtient un rapport de santé global
   */
  getHealthReport() {
    const report = {
      total: this.healthData.size,
      healthy: 0,
      degraded: 0,
      failing: 0,
      down: 0,
      unknown: 0,
      sources: []
    };

    this.healthData.forEach((health, sourceId) => {
      report[health.status]++;
      
      const totalAttempts = health.successCount + health.failureCount;
      const successRate = totalAttempts > 0 ? (health.successCount / totalAttempts * 100).toFixed(1) : 'N/A';
      
      report.sources.push({
        sourceId,
        status: health.status,
        successRate: successRate + '%',
        consecutiveFailures: health.consecutiveFailures,
        lastSuccess: health.lastSuccess,
        lastArticlesCount: health.lastArticlesCount,
        topError: this.getTopError(health.errorCounts)
      });
    });

    // Trier par statut (problèmes en premier)
    report.sources.sort((a, b) => {
      const statusPriority = { down: 0, failing: 1, degraded: 2, unknown: 3, healthy: 4 };
      return statusPriority[a.status] - statusPriority[b.status];
    });

    return report;
  }

  /**
   * Obtient l'erreur la plus fréquente
   */
  getTopError(errorCounts) {
    if (!errorCounts || Object.keys(errorCounts).length === 0) return null;
    
    return Object.entries(errorCounts)
      .sort((a, b) => b[1] - a[1])[0][0];
  }

  /**
   * Réinitialise les métriques d'une source
   */
  resetHealth(sourceId) {
    this.healthData.delete(sourceId);
    this.saveToStorage();
  }

  /**
   * Sauvegarde dans localStorage
   */
  saveToStorage() {
    try {
      const data = Array.from(this.healthData.entries());
      localStorage.setItem('firewatch_source_health', JSON.stringify(data));
    } catch (e) {
      console.error('Erreur sauvegarde health data:', e);
    }
  }

  /**
   * Charge depuis localStorage
   */
  loadFromStorage() {
    try {
      const stored = localStorage.getItem('firewatch_source_health');
      if (stored) {
        const data = JSON.parse(stored);
        this.healthData = new Map(data);
      }
    } catch (e) {
      console.error('Erreur chargement health data:', e);
      this.healthData = new Map();
    }
  }

  /**
   * Nettoie les anciennes données (> 30 jours)
   */
  cleanup() {
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
    
    this.healthData.forEach((health, sourceId) => {
      const lastChecked = new Date(health.lastChecked).getTime();
      if (lastChecked < thirtyDaysAgo) {
        this.healthData.delete(sourceId);
      }
    });
    
    this.saveToStorage();
  }
}

/**
 * Instance globale
 */
export const sourceHealthMonitor = new SourceHealthMonitor();

/**
 * Hook pour utiliser dans les composants React
 */
export const useSourceHealth = (sourceId) => {
  const [health, setHealth] = React.useState(null);

  React.useEffect(() => {
    const updateHealth = () => {
      const metrics = sourceHealthMonitor.getHealthMetrics(sourceId);
      setHealth(metrics);
    };

    updateHealth();
    
    // Mettre à jour toutes les 30 secondes
    const interval = setInterval(updateHealth, 30000);
    return () => clearInterval(interval);
  }, [sourceId]);

  return health;
};

/**
 * Tests unitaires
 */
export const testSourceHealth = () => {
  console.log('🧪 Tests du système de santé des sources');
  
  const monitor = new SourceHealthMonitor();
  const testSourceId = 'test-source-1';
  
  // Test 1: Nouvelles sources sont UNKNOWN
  console.log('Test 1: Statut initial');
  const initialHealth = monitor.getOrCreateHealth(testSourceId);
  console.log(initialHealth.status === SOURCE_STATUS.UNKNOWN ? '✅' : '❌', 'UNKNOWN');
  
  // Test 2: Succès change le statut à HEALTHY
  console.log('\nTest 2: Succès');
  monitor.recordSuccess(testSourceId, 10);
  console.log(monitor.getStatus(testSourceId) === SOURCE_STATUS.HEALTHY ? '✅' : '❌', 'HEALTHY');
  
  // Test 3: Échecs consécutifs changent le statut
  console.log('\nTest 3: Échecs consécutifs');
  for (let i = 0; i < 3; i++) {
    monitor.recordFailure(testSourceId, ERROR_TYPES.TIMEOUT);
  }
  console.log(monitor.getStatus(testSourceId) === SOURCE_STATUS.FAILING ? '✅' : '❌', 'FAILING');
  
  // Test 4: Rapport de santé
  console.log('\nTest 4: Rapport de santé');
  const report = monitor.getHealthReport();
  console.log('✅ Rapport généré:', JSON.stringify(report, null, 2));
  
  // Cleanup
  monitor.resetHealth(testSourceId);
  
  return true;
};