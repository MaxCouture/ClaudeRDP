import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  HelpCircle,
  RefreshCw,
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import { sourceHealthMonitor, SOURCE_STATUS } from '../utils/sourceHealthMonitor';

const STATUS_CONFIG = {
  [SOURCE_STATUS.HEALTHY]: {
    label: 'Sain',
    icon: CheckCircle,
    color: 'text-green-600',
    bgColor: 'bg-green-100',
    borderColor: 'border-green-200'
  },
  [SOURCE_STATUS.DEGRADED]: {
    label: 'Dégradé',
    icon: AlertCircle,
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-100',
    borderColor: 'border-yellow-200'
  },
  [SOURCE_STATUS.FAILING]: {
    label: 'Échoue',
    icon: AlertTriangle,
    color: 'text-orange-600',
    bgColor: 'bg-orange-100',
    borderColor: 'border-orange-200'
  },
  [SOURCE_STATUS.DOWN]: {
    label: 'Hors ligne',
    icon: XCircle,
    color: 'text-red-600',
    bgColor: 'bg-red-100',
    borderColor: 'border-red-200'
  },
  [SOURCE_STATUS.UNKNOWN]: {
    label: 'Inconnu',
    icon: HelpCircle,
    color: 'text-gray-600',
    bgColor: 'bg-gray-100',
    borderColor: 'border-gray-200'
  }
};

export default function SourceHealthPanel({ sources }) {
  const [healthReport, setHealthReport] = useState(null);
  const [showDetails, setShowDetails] = useState(true); // Ouvert par défaut dans la page Sources

  const refreshHealth = () => {
    const report = sourceHealthMonitor.getHealthReport();
    setHealthReport(report);
  };

  useEffect(() => {
    refreshHealth();
    const interval = setInterval(refreshHealth, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  if (!healthReport) return null;

  const problemSources = healthReport.sources.filter(s => 
    [SOURCE_STATUS.DOWN, SOURCE_STATUS.FAILING, SOURCE_STATUS.DEGRADED].includes(s.status)
  );

  return (
    <Card className="border-slate-200 bg-gradient-to-br from-white to-slate-50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Activity className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <CardTitle className="text-lg">État de santé des sources</CardTitle>
              <p className="text-xs text-gray-500 mt-0.5">
                Surveillance en temps réel des performances
              </p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={refreshHealth}
            className="h-8 w-8 p-0"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Résumé global avec pourcentages */}
        <div className="grid grid-cols-5 gap-3">
          {Object.entries(SOURCE_STATUS).map(([key, status]) => {
            const config = STATUS_CONFIG[status];
            const Icon = config.icon;
            const count = healthReport[status] || 0;
            const percentage = healthReport.total > 0 
              ? Math.round((count / healthReport.total) * 100) 
              : 0;

            return (
              <div 
                key={status}
                className={`p-4 rounded-xl border-2 ${config.borderColor} ${config.bgColor} transition-all hover:scale-105`}
              >
                <div className="flex items-center justify-between mb-2">
                  <Icon className={`w-5 h-5 ${config.color}`} />
                  <span className="text-3xl font-bold">{count}</span>
                </div>
                <div className={`text-xs font-semibold ${config.color} mb-1`}>
                  {config.label}
                </div>
                <div className="text-xs text-gray-500">
                  {percentage}% du total
                </div>
              </div>
            );
          })}
        </div>

        {/* Statistiques globales */}
        {healthReport.total > 0 && (
          <div className="grid grid-cols-2 gap-4 p-4 bg-white rounded-lg border">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <TrendingUp className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <div className="text-xs text-gray-500">Taux de succès global</div>
                <div className="text-lg font-bold">
                  {Math.round(((healthReport.healthy + healthReport.degraded) / healthReport.total) * 100)}%
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <TrendingDown className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <div className="text-xs text-gray-500">Sources en échec</div>
                <div className="text-lg font-bold">
                  {healthReport.failing + healthReport.down}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Alertes pour sources problématiques */}
        {problemSources.length > 0 ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-orange-600" />
                {problemSources.length} source{problemSources.length > 1 ? 's' : ''} nécessite{problemSources.length > 1 ? 'nt' : ''} votre attention
              </h4>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowDetails(!showDetails)}
                className="text-xs"
              >
                {showDetails ? 'Masquer' : 'Afficher'}
              </Button>
            </div>

            {showDetails && (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {problemSources.map(source => {
                  const sourceInfo = sources.find(s => s.id === source.sourceId);
                  const config = STATUS_CONFIG[source.status];
                  const Icon = config.icon;

                  return (
                    <div 
                      key={source.sourceId}
                      className={`p-4 rounded-lg border-2 ${config.borderColor} bg-white hover:shadow-md transition-all`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <Icon className={`w-5 h-5 ${config.color} flex-shrink-0`} />
                            <span className="font-semibold text-sm truncate">
                              {sourceInfo?.name || 'Source inconnue'}
                            </span>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                            <div className="bg-slate-50 p-2 rounded">
                              <div className="text-[10px] text-slate-500 uppercase font-medium mb-0.5">Taux de succès</div>
                              <div className="font-bold">{source.successRate}</div>
                            </div>
                            <div className="bg-slate-50 p-2 rounded">
                              <div className="text-[10px] text-slate-500 uppercase font-medium mb-0.5">Échecs consécutifs</div>
                              <div className="font-bold">{source.consecutiveFailures}</div>
                            </div>
                          </div>
                          {source.topError && (
                            <div className="mt-2 text-xs text-amber-700 bg-amber-50 p-2 rounded">
                              <strong>Erreur principale:</strong> {source.topError}
                            </div>
                          )}
                          {source.lastSuccess && (
                            <div className="mt-2 text-xs text-gray-500">
                              Dernier succès: {new Date(source.lastSuccess).toLocaleString('fr-CA')}
                            </div>
                          )}
                        </div>
                        <Badge className={`${config.bgColor} ${config.color} border-0 whitespace-nowrap`}>
                          {config.label}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          /* Message si tout va bien */
          <div className="flex items-center gap-3 text-sm text-green-600 bg-green-50 p-4 rounded-lg border-2 border-green-200">
            <CheckCircle className="w-5 h-5 flex-shrink-0" />
            <div>
              <div className="font-semibold">Toutes les sources fonctionnent normalement</div>
              <div className="text-xs text-green-600/80 mt-0.5">
                Aucun problème détecté lors des derniers scans
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}